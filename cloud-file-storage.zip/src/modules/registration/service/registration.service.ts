import { Injectable, ParseIntPipe } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { RegistrationDto } from 'src/models/DTO/registration/registration.dto';
import { Registration } from 'src/models/entities/registration/registration.entity';
import { Repository } from 'typeorm';

@Injectable()
export class RegistrationService {
    create(data: RegistrationDto) {
        throw new Error('Method not implemented.');
    }
    constructor(
        @InjectRepository(Registration, 'cloud_file_storage')
        @InjectConnection('cloud_file_storage')
        private readonly registrationRepository: Repository<Registration>,
    ){}

    async createNewUser(newUser: RegistrationDto): Promise<Registration> {
      try {
        return await this.registrationRepository.save(newUser);
      } catch (error) {
        throw error;
      }
    }

    async getAllUsers(): Promise<Registration[]> {
      try {
        return await this.registrationRepository.find();
      } catch (error) {
        throw error;
      }
    }

    async deleteUser(id: string): Promise<boolean> {
      try {
        const result = await this.registrationRepository.delete(id);
  
        return result.affected === 0 ? false : true;
      } catch (error) {
        throw error;
      }
    }



    async creatDynamicDatabase(newUser: RegistrationDto): Promise<any> {
      let p_userId= newUser.user_id;
      let p_cust_id = newUser.customer_id;
      let p_mobile_no = newUser.mobile_no;
      let p_user_name = newUser.user_name;
      let p_entry_type = newUser.entry_type;
      let p_user_category= newUser.user_category;
      let p_password = newUser.password;
      let p_photo_id = newUser.photo_id;
      let p_storage_limit_in_mb= newUser.storage_limit_in_mb;
      let p_block_app_access = newUser.block_app_access;
      let p_Authkey = newUser.Authkey;

      return await this.registrationRepository.query(`CALL cloud_file_storage.SP_CreateCloudFileStorageAppRegistration
      (
          ${p_userId},
         '${p_cust_id}',
         '${p_mobile_no}',
         '${p_user_name}',
         '${p_entry_type}',
         '${p_user_category}',
         '${p_password}', 
         '${p_photo_id}',
          ${p_storage_limit_in_mb},
          ${p_block_app_access} ,
         '${p_Authkey}'
      )`);}   
}










