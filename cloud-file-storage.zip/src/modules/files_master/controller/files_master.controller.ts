/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, HttpStatus, Post } from '@nestjs/common';
import ResponseInterface from 'src/common/interface/response.interface';
import { Files_master } from 'src/models/entities/files_master/files_master.entity';
import { Files_masterService } from '../service/files_master.service';

@Controller()
export class Files_masterController {
    constructor(private readonly filesmasterService: Files_masterService) {  
}

@Post('/insertFilesMaster')
async createNewUser(@Body() data: Files_master): Promise<ResponseInterface> {
  const newUser = await this.filesmasterService.insertFilesmaster(data);
  return {statusCode: HttpStatus.CREATED,message: 'insert Filesmaster successful'};
  }
}

