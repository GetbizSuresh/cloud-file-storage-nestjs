import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Files_masterDto } from 'src/models/DTO/files_master/files_master.dto';
import { Files_master } from 'src/models/entities/files_master/files_master.entity';
import { Repository } from 'typeorm';

@Injectable()
export class Files_masterService {
    create(data: Files_masterDto) {
        throw new Error('Method not implemented.');
}
constructor(
    @InjectRepository(Files_master, 'cloud_file_storage')
    @InjectConnection('cloud_file_storage')
    private readonly filesmasterRepository: Repository<Files_master>,
){}


async insertFilesmaster(obj_Files_masterDto: Files_masterDto): Promise<any> {
    let p_file_name= obj_Files_masterDto.file_name;
    let p_multiuser_file_access = obj_Files_masterDto.multiuser_file_access;
    let p_file_type = obj_Files_masterDto.file_type;
    let p_uploaded_created_by_user_id = obj_Files_masterDto.uploaded_created_by_user_id;
    let p_file_storage_url = obj_Files_masterDto.uploaded_created_timestamp;
    let p_uploaded_created_timestamp = obj_Files_masterDto.file_storage_url;
    let p_file_size = obj_Files_masterDto.file_size;
    let p_deleted_status = obj_Files_masterDto.deleted_status;
    let p_cust_id = obj_Files_masterDto.cust_id;

    return await this.filesmasterRepository.query(`CALL cloud_file_storage.SP_InsertFilesMaster
    (
       '${p_file_name}',
        ${p_multiuser_file_access},
       '${p_file_type}',
        ${p_uploaded_created_by_user_id},
       '${p_file_storage_url}',
       '${p_uploaded_created_timestamp}',
        ${p_file_size}, 
        ${p_deleted_status},
       '${p_cust_id}' 
       )`);} 
}
