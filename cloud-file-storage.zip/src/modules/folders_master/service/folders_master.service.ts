import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Folders_masterDto } from 'src/models/DTO/folders_master/folders_master.dto';
import { Folders_master } from 'src/models/entities/folders_master/folders.entity';
import { Repository } from 'typeorm';



@Injectable()
export class Folders_masterService {
  constructor(
    // @InjectRepository(Folders_master, 'cloud_file_storage')
    @InjectConnection('cloud_file_storage')
    private readonly foldersmasterRepository: Repository<any>,
  ) {}


  async insertFoldersmaster(
    obj_Folders_masterDto: Folders_masterDto,
  ): Promise<any> {
    let p_folder_name = obj_Folders_masterDto.folder_name;
    let p_multiuser_folder_access =
      obj_Folders_masterDto.multiuser_folder_access;
    let p_created_by_user_id = obj_Folders_masterDto.created_by_user_id;
    let p_folder_size = obj_Folders_masterDto.created_date_time;
    let p_deleted_status = obj_Folders_masterDto.folder_size;
    let p_created_timestamp = obj_Folders_masterDto.deleted_status;
    let p_cust_id = obj_Folders_masterDto.cust_id;

    // return await this.foldersmasterRepository
    //   .query(`CALL cloud_file_storage.SP_InsertFolderMaster(
    //     '${p_folder_name}',${p_multiuser_folder_access},
    //      ${p_created_by_user_id},${p_folder_size},
    //      ${p_deleted_status},'${p_created_timestamp}','${p_cust_id}'
    //    )`);

    var result = await this.foldersmasterRepository.query(`CALL cloud_file_storage.SP_InsertFolderMaster(
        '${p_folder_name}',${p_multiuser_folder_access},
         ${p_created_by_user_id},${p_folder_size},
         ${p_deleted_status},'${p_created_timestamp}','${p_cust_id}'
       )`);




       let folder_maxid = result.MaxId;












  }
}
