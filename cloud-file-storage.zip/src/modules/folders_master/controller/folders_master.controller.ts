import { Controller, Post, Body, HttpStatus } from "@nestjs/common";
import ResponseInterface from "src/common/interface/response.interface";
import { Folders_master } from "src/models/entities/folders_master/folders.entity";
import { Folders_masterService } from "../service/folders_master.service";

@Controller()
export class Folders_masterController {
    constructor(private readonly foldersmasterService: Folders_masterService) {  
    }
    
    
@Post('/insertFoldersMaster')
async createFoldermaster(@Body() data: Folders_master): Promise<ResponseInterface> {
  const result = await this.foldersmasterService.insertFoldersmaster(data);
  return {statusCode: HttpStatus.CREATED,message: 'insert foldermaster successfully'};
  }










}
