import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsDecimal, IsNotEmpty, isNumber, IsNumber, IsString } from "class-validator";
import decimal from 'decimal.js';


export class Files_masterDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  file_name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  multiuser_file_access: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  file_type: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  uploaded_created_by_user_id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  uploaded_created_timestamp: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  file_storage_url: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  deleted_status: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsDecimal()
  file_size: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  cust_id: string;

}
