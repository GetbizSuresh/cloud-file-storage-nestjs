import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import decimal from 'decimal.js';
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsNumber, IsString } from 'class-validator';

               //cloud_file_storage
export class Folders_masterDto {
  
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  folder_name: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  multiuser_folder_access: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  created_by_user_id: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  created_date_time: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  folder_size: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsBoolean()
  deleted_status: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  cust_id: string;

}
