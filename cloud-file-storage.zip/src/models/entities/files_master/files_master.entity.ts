import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import decimal from 'decimal.js';

@Entity({database:'cloud_file_storage',name:'files_master'})                  //cloud_file_storage
export class Files_master {
  
  @PrimaryGeneratedColumn()
  file_id: number;

  @Column()
  file_name: string;

  @Column()
  multiuser_file_access: boolean;

  @Column()
  file_type: number;

  @Column()
  uploaded_created_by_user_id: number;

  @Column()
  uploaded_created_timestamp: string;

  @Column()
  file_storage_url: string;

  @Column()
  deleted_status: boolean;

  @Column({
    type:'decimal'
  })
  file_size: number;

  @Column()
  cust_id: string;
  

}
