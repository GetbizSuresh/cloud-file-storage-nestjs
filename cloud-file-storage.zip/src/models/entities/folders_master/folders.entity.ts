import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';


@Entity({database:'cloud_file_storage',name:'folders_master'})                  //cloud_file_storage
export class Folders_master {
  
  @PrimaryGeneratedColumn()
  folder_id: number;

  @Column()
  folder_name: string;

  @Column()
  multiuser_folder_access: boolean;

  @Column()
  created_by_user_id: number;

  @Column()
  created_date_time: string;

  @Column()
  folder_size: number;

  @Column()
  deleted_status: boolean;

  @Column()
  cust_id: string;
  

}
